<?PHP // $Id: appointment.php,v 1.2.12.3 2006/02/06 09:59:30 moodler Exp $ 
      // appointment.php - created with Moodle 1.5.3+ (2005060230)


$string['allowresubmit'] = 'Permet tornar a trametre';
$string['appointmentdetails'] = 'Detalls de la cita';
$string['appointmentlocation'] = 'Ubicaci� de la cita';
$string['appointmentname'] = 'Nom de la cita';
$string['date'] = 'Data de la cita';
$string['description'] = 'Descripci�';
$string['early'] = '$a aviat';
$string['failedupdatefeedback'] = 'Ha fallat l\'actualitzaci� de la retroacci� en la tramesa de l\'usuari $a';
$string['feedback'] = 'Retroacci�';
$string['feedbackupdated'] = 'S\'ha actualitzat la retroacci� en les trameses de $a persones';
$string['late'] = '$a tard';
$string['maximumgrade'] = 'Nota m�xima';
$string['maximumsize'] = 'Mida m�xima';
$string['modulename'] = 'Cita';
$string['modulenameplural'] = 'Cites';
$string['newsubmissions'] = 'Les cites s\'han tram�s';
$string['notgradedyet'] = 'No s\'ha qualificat encara';
$string['notsubmittedyet'] = 'No s\'ha tram�s encara';
$string['overwritewarning'] = 'Av�s: si pengeu un fitxer una altra vegada REEMPLA�AREU la tramesa existent';
$string['saveallfeedback'] = 'Desa tota les meves retroaccions';
$string['submissionfeedback'] = 'Retroacci� per a la tramesa';
$string['submissions'] = 'Trameses';
$string['submitappointment'] = 'Trameteu la cita per mitj� d\'aquest formulari';
$string['submitted'] = 'S\'ha tram�s';
$string['timeend'] = 'Fi de la cita';
$string['timestart'] = 'Inici de la cita';
$string['typeoffline'] = 'Activitat fora de l�nia';
$string['typeuploadsingle'] = 'Penjar un fitxer';
$string['uploadbadname'] = 'El nom d\'aquest fitxer contenia car�cters estranys i no s\'ha pogut penjar';
$string['uploadedfiles'] = 'fitxers penjats';
$string['uploaderror'] = 'S\'ha produ�t un error mentre s\'estava desant el fitxer al servidor';
$string['uploadfailnoupdate'] = 'El fitxer s\'ha penjat correctament, per� no s\'ha pogut actualitzar la vostra tramesa!';
$string['uploadfiletoobig'] = 'Aquest fitxer �s massa gran (el l�mit s�n $a bytes)';
$string['uploadnofilefound'] = 'No s\'ha trobat cap fitxer - esteu segur que n\'heu seleccionat un per penjar-lo?';
$string['uploadnotregistered'] = '\'$a\' s\'ha penjat correctament, per� la tramesa no s\'ha registrat!';
$string['uploadsuccess'] = '\'$a\' s\'ha penjat amb �xit';
$string['viewfeedback'] = 'Visualitza les qualificacions i la retroacci� de la cita';
$string['viewsubmissions'] = 'Visualitza $a cites trameses';
$string['yoursubmission'] = 'La vostra tramesa';

?>
