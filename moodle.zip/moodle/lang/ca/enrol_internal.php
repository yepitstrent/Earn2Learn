<?PHP // $Id: enrol_internal.php,v 1.2.4.3 2006/02/06 09:59:30 moodler Exp $ 
      // enrol_internal.php - created with Moodle 1.5.3+ (2005060230)


$string['description'] = '<p>Aquest �s el m�tode per defecte de gesti� d\'inscripcions. B�sicament un estudiant es pot inscriure en un curs de dues maneres:</p>
<ul>
<li>Un professor o administrador l\'inscriuen a m� des del men� d\'Administraci� del curs</li>
<li>Un curs pot tenir definida una mena de contrasenya, coneguda com a \"clau d\'inscripci�\". Qualsevol que conegui aquesta clau pot entrar per si mateix al curs.</li>
</ul>';
$string['enrolname'] = 'Intern';

?>
