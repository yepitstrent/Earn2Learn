<?PHP // $Id: block_section_links.php,v 1.1.12.3 2006/02/06 09:59:30 moodler Exp $ 
      // block_section_links.php - created with Moodle 1.5.3+ (2005060230)


$string['blockname'] = 'Enlla�os de seccions';
$string['jumptocurrenttopic'] = 'Salta al tema actual';
$string['jumptocurrentweek'] = 'Salta a la setmana actual';
$string['topics'] = 'Temes';
$string['weeks'] = 'Setmanes';

?>
