<?PHP // $Id: activitynames.php,v 1.1.12.3 2006/02/06 09:59:29 moodler Exp $ 
      // activitynames.php - created with Moodle 1.5.3+ (2005060230)


$string['filtername'] = 'Enlla�os autom�tics a activitats';

?>
