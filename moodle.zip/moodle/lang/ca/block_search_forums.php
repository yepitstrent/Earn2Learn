<?PHP // $Id: block_search_forums.php,v 1.1.2.4 2006/02/06 09:59:30 moodler Exp $ 
      // block_search_forums.php - created with Moodle 1.5.3+ (2005060230)


$string['advancedsearch'] = 'Cerca avan�ada';
$string['blocktitle'] = 'Cerca f�rums';

?>
