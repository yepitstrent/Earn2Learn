<?PHP // $Id: block_course_list.php,v 1.1.6.3 2006/02/06 09:59:30 moodler Exp $ 
      // block_course_list.php - created with Moodle 1.5.3+ (2005060230)


$string['allcourses'] = 'L\'administrador veu tots els cursos';
$string['blockname'] = 'Llista de cursos';
$string['configadminview'] = 'Configuraci� de la visualitzaci� de l\'administrador';
$string['owncourses'] = 'L\'administrador veu els seus cursos';

?>
