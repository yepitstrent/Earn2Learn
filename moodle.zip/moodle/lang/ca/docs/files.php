<?php // $Id: files.php,v 1.1.10.3 2006/02/06 09:59:30 moodler Exp $
      // Names of the documentation files
      // Files with a definition "-" are treated as spacers

$string['-about'] = "Sobre Moodle";
$string['intro.html'] = "Introducci�";
$string['background.html'] = "Antecedents";
$string['philosophy.html'] = "Filosofia";
$string['licence.html'] = "Llic�ncia";
$string['features.html'] = "Caracter�stiques";
$string['release.html'] = "Notes de llan�ament";
$string['future.html'] = "Futur";
$string['credits.html'] = "Cr�dits";

$string['-installation'] = "Administraci�";
$string['install.html'] = "Instal�laci�";
$string['faq.html'] = "PMF d'instal�laci�";
$string['installamp.html'] = "Apache, MySQL, PHP";
$string['upgrade.html'] = "Actualitzaci�";

$string['-usage'] = "�s de Moodle";
$string['teacher.html'] = "Manual del professorat";
$string['other.html'] = "Altres documents";

$string['-development'] = "Desenvolupament";
$string['developer.html'] = "Manual de desenvolupament";
$string['coding.html'] = "Guia de codificaci�";
$string['cvs.html'] = "�s del CVS";
$string['translation.html'] = "Traducci�";

?>