<?PHP // $Id: enrol_database.php,v 1.1.6.3 2006/02/06 09:59:30 moodler Exp $ 
      // enrol_database.php - created with Moodle 1.5.3+ (2005060230)


$string['dbhost'] = 'Nom del servidor de la base de dades';
$string['dbname'] = 'La base de dades que cal utilitzar';
$string['dbpass'] = 'Contrasenya per accedir al servidor';
$string['dbtable'] = 'Taula de la base de dades';
$string['dbtype'] = 'Tipus de servidor de bases de dades';
$string['dbuser'] = 'Nom d\'usuari per accedir a la base de dades';
$string['description'] = 'Podeu fer servir una base de dades externa (gaireb� de qualsevol mena) per controlar les inscripcions. Se suposa que la base de dades externa t� un camp que cont� un ID de curs i un altre camp amb un ID d\'usuari. Aquests camps es comparen amb els camps que trieu de les taules locals de cursos i d\'usuaris.';
$string['enrolname'] = 'Base de dades externa';
$string['localcoursefield'] = 'El nom del camp de la taula local de cursos que s\'utilitzar� per comparar les entrades de la base de dades remota (p. ex. idnumber)';
$string['localuserfield'] = 'El nom del camp de taula local d\'usuaris que s\'utilitzar� per comparar amb el registre remort (p. ex. idumber)';
$string['remotecoursefield'] = 'El camp de la base de dades remota en el qual s\'espera trobar l\'ID del curs';
$string['remoteuserfield'] = 'El camp de la base de dades remota en el qual s\'espera trobar l\'ID de l\'usuari';

?>
