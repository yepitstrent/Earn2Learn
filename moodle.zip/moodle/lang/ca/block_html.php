<?PHP // $Id: block_html.php,v 1.2.2.3 2006/02/06 09:59:30 moodler Exp $ 
      // block_html.php - created with Moodle 1.5.3+ (2005060230)


$string['configcontent'] = 'Contingut';
$string['configtitle'] = 'T�tol del bloc';
$string['html'] = 'HTML';
$string['leaveblanktohide'] = 'Deixeu en blanc per ocultar el t�tol';
$string['newhtmlblock'] = '(nou bloc HTML)';

?>
