<?PHP // $Id: block_online_users.php,v 1.1.12.3 2006/02/06 09:59:30 moodler Exp $ 
      // block_online_users.php - created with Moodle 1.5.3+ (2005060230)


$string['blockname'] = 'Usuaris en l�nia';
$string['configtimetosee'] = 'Nombre de minuts per considerar que un usuari est� en l�nia';
$string['periodnminutes'] = 'darrers $a minuts';

?>
