<?PHP // $Id: block_course_summary.php,v 1.5.2.3 2006/02/06 09:59:30 moodler Exp $ 
      // block_course_summary.php - created with Moodle 1.5.3+ (2005060230)


$string['coursesummary'] = 'Resum del curs';
$string['pagedescription'] = 'Descripci� del curs/lloc';

?>
