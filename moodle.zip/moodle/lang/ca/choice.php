<?PHP // $Id: choice.php,v 1.11.2.3 2006/02/06 09:59:30 moodler Exp $ 
      // choice.php - created with Moodle 1.5.3+ (2005060230)


$string['addmorechoices'] = 'Afegeix m�s opcions';
$string['allowupdate'] = 'Permet actualitzar la consulta';
$string['answered'] = 'Contestades';
$string['choice'] = 'Opci� $a';
$string['choiceclose'] = 'Fins';
$string['choicename'] = 'T�tol de la consulta';
$string['choiceopen'] = 'Oberta';
$string['choicetext'] = 'Text de la consulta';
$string['displayhorizontal'] = 'En horitzontal';
$string['displaymode'] = 'Mode de visualitzaci�';
$string['displayvertical'] = 'En vertical';
$string['full'] = '(Complet)';
$string['havetologin'] = 'Abans de trametre una resposta heu d\'entrar amb el vostre nom d\'usuari i contrasenya.';
$string['limit'] = 'L�mit';
$string['limitanswers'] = 'Limita el nombre de respostes permeses';
$string['modulename'] = 'Consulta';
$string['modulenameplural'] = 'Consultes';
$string['mustchooseone'] = 'Heu de triar una resposta abans de desar. No s\'ha desat res.';
$string['notanswered'] = 'No contestada encara';
$string['notopenyet'] = 'Aquesta activitat no est� disponible fins el $a';
$string['privacy'] = 'Confidencialitat dels resultats';
$string['publish'] = 'Publica els resultats';
$string['publishafteranswer'] = 'Mostra els resultats als estudiants despr�s que contestin';
$string['publishafterclose'] = 'Mostra els resultats als estudiants quan es tanqui la consulta';
$string['publishalways'] = 'Mostra sempre els resultats als estudiants';
$string['publishanonymous'] = 'Publica els resultats an�nimament, sense mostrar els noms dels estudiants';
$string['publishnames'] = 'Publica els resultats complets, amb els noms dels estudiants i les seves respostes';
$string['publishnot'] = 'No publiquis els resultats';
$string['responses'] = 'Respostes';
$string['responsesto'] = 'Respostes per a $a';
$string['savemychoice'] = 'Desa la meva resposta';
$string['showunanswered'] = 'Mostra columna de no contestades';
$string['spaceleft'] = 'Espai disponible';
$string['spacesleft'] = 'Espais disponibles';
$string['taken'] = 'Ocupat';
$string['timerestrict'] = 'Limita les respostes a aquest per�ode de temps';
$string['viewallresponses'] = 'Visualitza $a respostes';
$string['yourselection'] = 'La vostra selecci�';

?>
