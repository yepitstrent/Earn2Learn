<?PHP // $Id: enrol_paypal.php,v 1.1.6.3 2006/02/06 09:59:30 moodler Exp $ 
      // enrol_paypal.php - created with Moodle 1.5.3+ (2005060230)


$string['business'] = 'L\'adre�a de correu electr�nic del vostre compte de Paypal';
$string['costorkey'] = 'Trieu un dels m�todes d\'inscripci� seg�ents.';
$string['description'] = 'El m�dul Paypal permet configurar cursos de pagament. Si el cost d\'un curs �s zero, aleshores no es demana als estudiants que paguin per entrar-hi. Hi ha un cost general del lloc que definiu aqu� com a cost per defecte de tots els cursos del lloc i un par�metre del curs que podeu definir per a cada curs individualment. El cost del curs t� prefer�ncia sobre el cost per defecte.';
$string['enrolname'] = 'Paypal';
$string['sendpaymentbutton'] = 'Envia pagament via Paypal';

?>
