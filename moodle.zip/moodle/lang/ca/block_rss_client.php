<?PHP // $Id: block_rss_client.php,v 1.2.2.3 2006/02/06 09:59:30 moodler Exp $ 
      // block_rss_client.php - created with Moodle 1.5.3+ (2005060230)


$string['addfeed'] = 'Afegeix un URL d\'alimentaci� de not�cies:';
$string['addheadlineblock'] = 'Afegeix un bloc de titulars RSS';
$string['addnew'] = 'Afegeix';
$string['choosefeedlabel'] = 'Trieu les alimentacions que voleu incloure en aquest bloc:';
$string['clientchannellink'] = 'Lloc origen...';
$string['clientnumentries'] = 'Nombre d\'entrades de cada alimentaci� que es mostren per defecte.';
$string['clientshowchannellinklabel'] = 'S\'ha de mostrar un enlla� al lloc (canal) original? (sempre que l\'alimentaci� proporcioni l\'enlla�):';
$string['clientshowimagelabel'] = 'Mostra la imatge del canal (si n\'hi ha):';
$string['configblock'] = 'Configura aquest bloc';
$string['couldnotfindfeed'] = 'No s\'ha trobat l\'alimentaci� amb id';
$string['customtitlelabel'] = 'T�tol personalitzat (deixeu en blanc per utilitzar el que proporciona l\'alimentaci�)';
$string['deletefeedconfirm'] = 'Esteu segur que voleu suprimir aquesta alimentaci�?';
$string['displaydescriptionlabel'] = 'Cal visualitzar la descripci� de cada enlla�?';
$string['editfeeds'] = 'Editar, afegeix subscripcions o cancel�la subscripcions a alimentacions de not�cies RSS/Atom';
$string['editnewsfeeds'] = 'Edita alimentacions de not�cies';
$string['editrssblock'] = 'Edita bloc de titulars RSS';
$string['feed'] = 'Alimentaci� de not�cies';
$string['feedadded'] = 'S\'ha afegit una alimentaci� de not�cies';
$string['feeddeleted'] = 'S\'ha suprimit una alimentaci� de not�cies';
$string['feeds'] = 'Alimentacions de not�cies';
$string['feedsaddedit'] = 'Afegeix/edita alimentacions';
$string['feedsconfigurenewinstance'] = 'Feu clic aqu� per configurar la visualitzaci� d\'RSS en aquest bloc.';
$string['feedstitle'] = 'Alimentacions RSS remotes';
$string['feedupdated'] = 'S\'ha actualitzat una alimentaci� de not�cies';
$string['findmorefeeds'] = 'Cerca m�s alimentacions RSS';
$string['managefeeds'] = 'Gestiona les meves alimentacions';
$string['nofeeds'] = 'No hi ha alimentacions RSS definides en aquest lloc ';
$string['pickfeed'] = 'Tria una alimentaci� de not�cies';
$string['remotenewsfeed'] = 'Alimentaci� de not�cies remotes';
$string['seeallfeeds'] = 'Mostra totes les alimentacions';
$string['shownumentrieslabel'] = 'Nombre m�xim d\'entrades que es pot visualitzar en un bloc';
$string['submitters'] = 'Qui pot definir noves alimentacions RSS? Les alimentacions ja definides estan disponibles per a qualsevol p�gina del lloc.';
$string['timeout'] = 'Temps d\'espera RSS';
$string['timeoutdesc'] = 'Temps en minuts que una alimentaci� RSS roman a la mem�ria cau';
$string['updatefeed'] = 'Actualitza l\'URL d\'una alimentaci� de not�cies';
$string['validatefeed'] = 'Valida alimentaci�';

?>
