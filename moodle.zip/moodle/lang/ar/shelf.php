<?PHP // $Id: shelf.php,v 1.6.2.3 2006/02/06 09:59:26 moodler Exp $ 
      // shelf.php - created with Moodle 1.2 development (2004011700)


$string['modulename'] = '��';
$string['modulenameplural'] = '����';

?>
