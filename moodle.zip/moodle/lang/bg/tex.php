<?PHP // $Id: tex.php,v 1.1.4.3 2006/02/06 09:59:29 moodler Exp $ 
      // tex.php - created with Moodle 1.4.1+ (2004083101)


$string['filtername'] = 'TeX �������';

?>
