<?PHP // $Id: tex.php,v 1.1.4.3 2006/02/06 09:59:26 moodler Exp $ 
      // tex.php - created with Moodle 1.3.1 + (2004052501)


$string['filtername'] = 'T�X ������';

?>