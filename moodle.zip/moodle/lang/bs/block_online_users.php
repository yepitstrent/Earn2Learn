<?PHP // $Id: block_online_users.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // block_online_users.php - created with Moodle 1.4.3 + (2004083131)


$string['blockname'] = 'Online korisnici';
$string['configtimetosee'] = 'Broj minuta za otkrivanje aktivnog korisnika';
$string['periodnminutes'] = 'zadnjih $a minuta';

?>
