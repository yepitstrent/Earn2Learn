<?PHP // $Id: choice.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // choice.php - created with Moodle 1.4.3 + (2004083131)


$string['allowupdate'] = 'Dopusti da izbor bude obnovljen';
$string['answered'] = 'Odgovoreno';
$string['choice'] = 'Izbor $a';
$string['choiceclose'] = 'Do';
$string['choicename'] = 'Naziv izbora';
$string['choiceopen'] = 'Otvori';
$string['choicetext'] = 'Tekst izbora';
$string['havetologin'] = 'Prije nego potvrdite Va� izbor morate se upisati';
$string['modulename'] = 'Izbor';
$string['modulenameplural'] = 'Izbori';
$string['mustchooseone'] = 'Morate izabrati jedan od odgovora prije snimanja. Ni�ta ne�e biti sa�uvano';
$string['notanswered'] = 'Jo� neodgovoreno';
$string['notopenyet'] = '�ao mi je, ova aktivnost nije dostupna do $a';
$string['privacy'] = 'Povjerljivost rezultata';
$string['publish'] = 'Objava rezultata';
$string['publishafteranswer'] = 'Prika�i rezultate studentima nakon njihovog odgovora';
$string['publishafterclose'] = 'Prika�i rezultate studentima jedino nakon �to je izbor zatvoren';
$string['publishalways'] = 'Uvijek prika�i rezultate studentima';
$string['publishanonymous'] = 'Objava anonimnih rezultata, bez prikaza imena studenata';
$string['publishnames'] = 'Objava punih rezultata, s prikazom imena i napravljenih izbora';
$string['publishnot'] = 'Bez objave rezultata studentima';
$string['responses'] = 'Odgovori';
$string['responsesto'] = 'Odgovori za $a';
$string['savemychoice'] = 'Sa�uvaj moj izbor';
$string['showunanswered'] = 'Prika�i kolonu za neodgovoreno';
$string['timerestrict'] = 'Ograni�i odgovore na ovaj vremenski period';
$string['viewallresponses'] = 'Pregled $a odgovora';

?>
