<?PHP // $Id: label.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // label.php - created with Moodle 1.4.3 + (2004083131)


$string['labeltext'] = 'Tekst natpisa';
$string['modulename'] = 'Natpis';
$string['modulenameplural'] = 'Natpisi';

?>
