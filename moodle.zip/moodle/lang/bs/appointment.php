<?PHP // $Id: appointment.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // appointment.php - created with Moodle 1.4.3 + (2004083131)


$string['allowresubmit'] = 'Dozvoli ponovno slanje';
$string['appointmentdetails'] = 'Detalji o sastanku';
$string['appointmentlocation'] = 'Mjesto sastanka';
$string['appointmentname'] = 'Naziv sastanka';
$string['date'] = 'Datum sastanka';
$string['description'] = 'Opis';
$string['early'] = '$a ranije';
$string['failedupdatefeedback'] = 'Ne uspjela nadogradnja prijedloga povratne informacije za korisnike $a';
$string['feedback'] = 'Povratna informacija';
$string['feedbackupdated'] = 'Prijedlog povratne informacije nadogra�ene za $a korisnike';
$string['late'] = '$a kasnije';
$string['maximumgrade'] = 'Najve�a ocjena';
$string['maximumsize'] = 'Maksimalna veli�ina';
$string['modulename'] = 'Sastanak';
$string['modulenameplural'] = 'Sastanci';
$string['newsubmissions'] = 'Sastanci prihva�eni';
$string['notgradedyet'] = 'Jo� nije ocjenjen';
$string['notsubmittedyet'] = 'Jo� nije prihva�en';
$string['overwritewarning'] = 'Upozorenje: ponovna nadogradnja �e zamijeniti Va� trenutni prijedlog';
$string['saveallfeedback'] = 'Snimi sve moje povratne informacije';
$string['submissionfeedback'] = 'Prijedlog povratne informacije';
$string['submissions'] = 'Prijedlozi';
$string['submitappointment'] = 'Proslijedi svoj sastanak upotrijebljavaju�i ovu formu';
$string['submitted'] = 'Prihva�eno';
$string['timeend'] = 'Zavr�etak sastanka';
$string['timestart'] = 'Po�etak sastanka';
$string['typeoffline'] = 'Izvan mre�na aktivnost';
$string['typeuploadsingle'] = 'Postavi jednu datoteku';
$string['uploadbadname'] = 'Ova datoteka sadr�i neobi�ne znakove u svom nazivu i ne mo�e biti postavljena';
$string['uploadedfiles'] = 'postavljene datoteke';
$string['uploaderror'] = 'Pojavila se gre�ka pri poku�aju snimanja datoteke na server';
$string['uploadfailnoupdate'] = 'Datoteka je uredno u�itana ali ne mo�ete nadograditi svoj prijedlog!';
$string['uploadfiletoobig'] = '�ao nam je, ali datoteka je prevelika (limit je $a bajta)';
$string['uploadnofilefound'] = 'Datoteka nije prona�ena - da li ste sigurni da ste izabrali datoteku?';
$string['uploadnotregistered'] = '\'$a\' je uredno u�itana ali prijedlog nije registrovan!';
$string['uploadsuccess'] = 'U�itavanje \'$a\' je uspjelo';
$string['viewfeedback'] = 'Pregledaj ocjene i povratne informacije sastanka';
$string['viewsubmissions'] = 'Pregledaj $a prihva�ene sastanke';
$string['yoursubmission'] = 'Va� prijedlog';

?>
