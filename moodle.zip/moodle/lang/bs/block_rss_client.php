<?PHP // $Id: block_rss_client.php,v 1.2.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // client.php - created with Moodle 1.4.3 + (2004083131)


$string['addheadlineblock'] = 'Dodajte RSS glavni naslov bloka';
$string['addnew'] = 'Dodajte novi';
$string['choosefeed'] = 'Izaberite i podesite za izlaganje u ovaj  blok:';
$string['couldnotfindfeed'] = 'Ne mogu prona�i pode�avanje sa ID';
$string['deletefeedconfirm'] = 'Da li ste sigurni da �elite obrisati ovo pode�avanje?';
$string['displaydescription'] = 'Izlo�ite svaki opis linka?';
$string['editfeeds'] = 'Korigujte, upi�ite ili ispi�ite sa RSS/Atom novo pode�avanje';
$string['editnewsfeeds'] = 'Korigujte novo pode�avanje';
$string['editrssblock'] = 'Korigujte RSS glavni naslov blok';
$string['feed'] = 'Novo pode�avanje';
$string['feedadded'] = 'Dodajte novo pode�avanje';
$string['feeddeleted'] = 'Obri�ite novo pode�avanje';
$string['feedupdated'] = 'Nadogradite novo pode�avanje';
$string['feeds'] = 'Nova pode�avanja';
$string['feedsaddedit'] = 'Dodajte / Korigujte pode�avanja';
$string['feedstitle'] = 'Pode�avanja RSS na daljinu';
$string['findmorefeeds'] = 'Prona�ite vi�e RSS pode�avanja';
$string['nofeeds'] = 'Nema RSS pode�avanja definisanih za ovu stranicu.';
$string['numentries'] = 'Broj RSS linkova prikazanih po bloku.';
$string['pickfeed'] = 'Pokupi novo pode�avanje';
$string['remotenewsfeed'] = 'Premjesti novo pode�avanje';
$string['seeallfeeds'] = 'Pregledaj sva pode�avanja';
$string['shownumentries'] = 'Maksimalan broj kolona prikazanih po bloku.';
$string['submitters'] = 'Ko mo�e definisati nova RSS pode�avanja? Pode�avanja su napravljena raspolo�ivim za bilo kojeg �lana Va�eg sajta za dodavanje njihovih vlastitih stranica.';
$string['timeout'] = 'blockrsstimeout';
$string['timeoutdesc'] = 'Vrijeme u minutima za RSS pode�avanje aktuelne brze memorije.';
$string['wordtitle'] = 'Naslov';

?>
