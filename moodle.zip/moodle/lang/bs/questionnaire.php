<?PHP // $Id: questionnaire.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // questionnaire.php - created with Moodle 1.4.3 + (2004083131)


$string['alreadyfilled'] = 'Ve� ste imali popunjenu ovu anketu za nas. Hvala Vam.';
$string['modulename'] = 'Anketa';
$string['modulenameplural'] = 'Ankete';
$string['mustcomplete'] = '<b>Morate kompletirati ovu anketu <i>sada</i> da bi snimili svoje rezultate. Ne�e Vam biti dozvoljeno da kompletirate to drugi put</b><br /><br />';
$string['notavail'] = 'Ta anketa jo� nije dostupna. Poku�ajte ponovo kasnije.';
$string['qmanage'] = 'Upravljanje istra�ivanjem';
$string['qmanagetitle'] = 'Nadzor menad�menta phpESP';
$string['qtype'] = 'Tip';
$string['questionnaireid'] = 'Nadzor';
$string['respondenttype'] = 'Odgovaraju�i tip';

?>
