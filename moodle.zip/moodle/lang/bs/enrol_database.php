<?PHP // $Id: enrol_database.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // enrol_database.php - created with Moodle 1.4.3 + (2004083131)


$string['dbhost'] = 'Baza podataka  glavnog servera';
$string['dbname'] = 'Specifi�na baza podataka za upotrebu';
$string['dbpass'] = 'Lozinka za pristup serveru';
$string['dbtable'] = 'Spisak u toj bazi podataka';
$string['dbtype'] = 'Tip serverske baze podataka';
$string['dbuser'] = 'Korisni�ko ime za pristup serveru';
$string['description'] = 'Mo�ete upotrijebiti vanjsku bazu podataka (pribli�no jednako dobro) za kontrolu Va�eg upisa.  To sadr�anom simulira Va�u vanjsku bazu podataka sadr�ajem polja kursa ID, i sadr�ajem polja korisnika ID.  Oni se porede nasuprot polja, sa mogu�no��u biranja u lokalnom kursu, i korisni�kog spiska.';
$string['enrolname'] = 'Vanjska baza podataka';
$string['localcoursefield'] = 'Ime polja u spisku kursa gdje mi koristimo tako puno kolona u nekada�njoj bazi podataka (eg id broj)';
$string['localuserfield'] = 'Ime polja na lokalnom korisni�kom spisku gdje mi koristimo tako puno korisnika u nekada�njem dokumentu (eg id broj)';
$string['remotecoursefield'] = 'Mi o�ekujemo da na�emo ID kursa u polju u nekada�njoj bazi podataka';
$string['remoteuserfield'] = 'Mi o�ekujemo da na�emo ID korisnika u polju u nekada�njoj bazi podataka';

?>
