<?PHP // $Id: journal.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // journal.php - created with Moodle 1.4.3 + (2004083131)


$string['alwaysopen'] = 'Uvijek otvoren';
$string['blankentry'] = 'Nema unosa';
$string['daysavailable'] = 'Dana na raspolaganju';
$string['editingended'] = 'Period ure�ivanja je zavr�en';
$string['editingends'] = 'Period ure�ivanja zavr�ava';
$string['entries'] = 'Unosi';
$string['feedbackupdated'] = 'Povratne informacije su a�urirane za $a unose';
$string['journalmail'] = '$a->teacher je poslao povratne informacije u vezi Va�eg unosa za \'$a->journal\'  Pogledajte ovdje:      $a->url ';
$string['journalmailhtml'] = '$a->teacher je poslao povratne informacije u vezi Va�eg unosa za \'<i>$a->journal</i>\'<br /><br /> Pogledajte <a href=\"$a->url\">unos dnevnika</a>. ';
$string['journalname'] = 'Ime dnevnika';
$string['journalquestion'] = 'Pitanje za dnevnik';
$string['journalrating1'] = 'Ne zadovoljava';
$string['journalrating2'] = 'Zadovoljavaju�e';
$string['journalrating3'] = 'Istaknuto';
$string['modulename'] = 'Dnevnik';
$string['modulenameplural'] = 'Dnevnici';
$string['newjournalentries'] = 'Novi unos dnevnika';
$string['noentry'] = 'Bez naslova';
$string['noratinggiven'] = 'Ocjenjivanje nije unijeto';
$string['notopenuntil'] = 'Ovaj dnevnik ne�e biti otvoren sve do';
$string['notstarted'] = 'Ovaj dnevnik je za sada nedostupan';
$string['overallrating'] = 'Kona�no rangiranje';
$string['rate'] = 'Rangiranje';
$string['saveallfeedback'] = 'Sa�uvaj sve moje odgovore';
$string['startoredit'] = 'Pokreni ili upi�i naslov svog dnevnika';
$string['viewallentries'] = 'Pogled na $a unose dnevnika';

?>
