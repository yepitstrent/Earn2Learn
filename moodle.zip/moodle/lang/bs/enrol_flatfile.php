<?PHP // $Id: enrol_flatfile.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // enrol_flatfile.php - created with Moodle 1.4.3 + (2004083131)


$string['description'] = 'Ova metoda �e biti vi�e puta obra�ena za provjeru i obradu posebno oblikovanog teksta datoteke na lokaciji koju Vi nazna�ite.  Datoteka mo�e izgledati sli�no kao ova: 
<pre>
   dodaj, studenta, 5, CF101
   dodaj, nastavnika, 6, CF101
   dodaj, pode�avanje nastavnika, 7, CF101
   obri�i, studenta, 8, CF101
   obri�i, studenta, 17, CF101
   dodaj, studenta, 21, CF101, 1091115000, 1091215000
</pre>';
$string['enrolname'] = 'Izri�ita datoteka';
$string['filelockedmail'] = 'Tekst datoteka koju koristite za arhivu baziranoj na upisu ($a) ne mo�e biti obrisana kron procesom.  Ovo se obi�no odnosi na pogre�ne saglasnosti.  Molimo Vas da podesite dozvolu da bi modul obrisao datoteku, ina�e bi mogla biti obra�ena vi�e puta.';
$string['filelockedmailsubject'] = 'Va�na gre�ka: Spisak  datoteka';
$string['location'] = 'Lokacija datoteke';
$string['mailadmin'] = 'Obavijesti administratora mailom';
$string['mailusers'] = 'Obavijesti korisnika mailom';

?>
