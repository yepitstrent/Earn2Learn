<?PHP // $Id: multilang.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // multilang.php - created with Moodle 1.4.3 + (2004083131)


$string['filtername'] = 'Multi - jezi�ki sadr�aj';

?>
