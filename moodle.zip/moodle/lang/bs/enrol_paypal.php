<?PHP // $Id: enrol_paypal.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // enrol_paypal.php - created with Moodle 1.4.3 + (2004083131)


$string['business'] = 'Adresa e-po�te na Va�em poslovnom Paypal ra�unu';
$string['description'] = 'Paypal modul dozvoljava Vam da podesite upla�ivanje kurseva.  Ako je tro�ak za bilo koji kurs nula, onda studenti ne pitaju da plate za ulaz. Ovdje je sajt opse�an tro�ak tada tu mo�ete postaviti kao podrazumijevanu vrijednost na cijelom sajtu i onda pode�avanja kursa koja mo�ete posatviti pojedina�no za svaki kurs. Vrijednovanje kursa mimoilazi vrijednost sajta.';
$string['enrolname'] = 'Paypal';
$string['sendpaymentbutton'] = 'Po�aljete nagra�ivanje Paypal';

?>
