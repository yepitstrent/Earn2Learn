<?PHP // $Id: pix.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // pix.php - created with Moodle 1.4.3 + (2004083131)


$string['angry'] = 'ljut';
$string['approve'] = 'pohvaljen';
$string['biggrin'] = 'veliki smije�ak';
$string['blackeye'] = 'crno oko';
$string['blush'] = 'pocrvenjen';
$string['clown'] = 'klaun';
$string['cool'] = 'spokojan';
$string['dead'] = 'mrtav';
$string['evil'] = 'zao';
$string['kiss'] = 'poljubac';
$string['mixed'] = 'izmije�an';
$string['sad'] = 'tu�an';
$string['shy'] = 'stidljiv';
$string['sleepy'] = 'pospan';
$string['smiley'] = 'smije�ak';
$string['surprise'] = 'iznena�enje';
$string['thoughtful'] = 'zami�ljen';
$string['tongueout'] = 'ispla�en';
$string['wideeyes'] = '�iroke o�i';
$string['wink'] = 'namigivanje';

?>
