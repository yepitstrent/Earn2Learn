<?PHP // $Id: book.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // book.php - created with Moodle 1.4.3 + (2004083131)


$string['addafter'] = 'Dodaj novo poglavlje';
$string['chapterscount'] = 'Poglavlja';
$string['chaptertitle'] = 'Naslov poglavlja';
$string['confchapterdelete'] = 'Da li stvarno �elite izbrisati ovo poglavlje?';
$string['confchapterdeleteall'] = 'Da li stvarno �elite izbrisati ovo poglavlje i sva njegova podpoglavlja?';
$string['content'] = 'Sadr�aj';
$string['customtitles'] = 'Prilago�eni nazivi';
$string['disableprinting'] = 'Isklju�i �tampanje';
$string['doimport'] = 'Ubaci';
$string['editingchapter'] = 'Ure�ivanje poglavlja';
$string['faq'] = '�esta pitanja';
$string['fileordir'] = 'Datoteka ili direktorij';
$string['import'] = 'Ubaci';
$string['importinfo'] = 'Ubaci izabranu HTML datoteku ili direktorij.<br />Poglavlja su sortirana po abecedi koriste�i imena.';
$string['importing'] = 'Ubacujem';
$string['importingchapters'] = 'Ubacujem poglavlja u knjigu';
$string['maindirectory'] = 'Glavni direktorij';
$string['modulename'] = 'Knjiga';
$string['modulenameplural'] = 'Knjige';
$string['navexit'] = 'Iza�i iz knjige';
$string['navnext'] = 'Sljede�i';
$string['navprev'] = 'Prethodni';
$string['numbering'] = 'Numerisanje poglavlja';
$string['numbering0'] = 'ni�ta';
$string['numbering1'] = 'Brojevi';
$string['numbering2'] = 'Grafi�ka oznaka';
$string['numbering3'] = 'Razvedene';
$string['printbook'] = 'O�tampaj �itavu knjigu';
$string['printchapter'] = 'O�tampaj ovo poglavlje';
$string['printdate'] = 'Datum';
$string['printedby'] = '�tampao';
$string['relinking'] = 'Preusmjeravam';
$string['subchapter'] = 'Podpoglavlje';
$string['toc'] = 'Sadr�aj';
$string['tocwidth'] = 'Izaberi �irinu Sadr�aja za sve knjige';
$string['top'] = 'vrh';

?>
