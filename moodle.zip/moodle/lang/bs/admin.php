<?PHP // $Id: admin.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // admin.php - created with Moodle 1.4.3 + (2004083131)


$string['adminseesallevents'] = 'Administratori vide sve rezultate';
$string['adminseesownevents'] = 'Administratori su kao ostali korisnici';
$string['blockinstances'] = 'Instanca';
$string['blockmultiple'] = 'Mnogostruk';
$string['cachetext'] = 'Vrijeme trajanja skrivene memorije teksta';
$string['calendarsettings'] = 'Kalendar';
$string['change'] = 'promjena';
$string['confirmation'] = 'Potvrda';
$string['confirmdeletedst'] = 'Brisanje pode�enog imena <strong>$a</strong> odmah �e onemogu�itit DST za sve pode�ene korisnike. Ovo �e bez upozorenja mo�da promijeniti njihovo vi�enje datuma. Da li ste sigurni da �elite nastaviti?';
$string['confirmdeletedstdefault'] = '<strong>pode�eno ime $a je postojan korisnik za sve korisnike na ovoj stranici!</strong> Brisanjem ovoga promijenit �e se njegovo vi�enje datuma bez upozorenja. Da li ste sigurni da �elite nastaviti?';
$string['dstisapreference'] = 'Svaki od korisnika mo�e birati koje �e pode�avanje koristiti.';
$string['dstisforcedto'] = 'Forsiraj sve korisnike da upotrebljavaju DST';
$string['dstpresets'] = 'DST postavka';
$string['editingdstpreset'] = 'Podesi DST postavku';
$string['emptydstlist'] = 'Trenutno nema DST definisanih postavki. Mo�ete dodati jednu klikom na DODAJ dugme.';
$string['errordstpresetactivateearlier'] = 'Mjesec aktvacije mora biti raniji od mjeseca neaktivacije';
$string['errordstpresetnameempty'] = 'Postavljeni unos za ime ne mo�e biti prazan';
$string['errordstpresetnameexists'] = 'Ve� postoji postavka sa istim imenom';
$string['filteruploadedfiles'] = 'Filter o�itanih datoteka';
$string['helpadminseesall'] = 'U�ini da administratori vide sve kalendare iako su dodati od strane njih samih.';
$string['helpcalendarsettings'] = 'Konfiguri�i varjabile za kalendare i datum/vrijeme relacije sa aspekta Moodla';
$string['helpdstforusers'] = 'Mo�e li svaki korisnik birati svoja DST pode�avanja?';
$string['helpmanagedstpresets'] = 'Klikni na ovaj taster da doda�, uredi� i obri�e� DST postavku koja je na raspolaganju ovoj stranici.';
$string['helpstartofweek'] = 'Koji �e dan biti po�etak sedmice u kalendaru?';
$string['helpupcominglookahead'] = 'Koliko dana u budu�nosti je pribli�no pregledno isoda u kalendaru po podrazumijevanoj opciji?';
$string['helpupcomingmaxevents'] = 'Koliko pribli�no mnogo (maksimalno) ishoda je prikazano korisnicima po podrazumijevanoj opciji.';
$string['helpweekenddays'] = 'Koji dan je u sedmici tretiran kao vikend i prika�i ga sa razli�itom bojom?';
$string['managedstpresets'] = 'Izvr�iti DST postavku';
$string['nodstpresetsexist'] = 'DST podr�ka je onemogu�ena svim korisnicima zato �to nema definisanih DST postavki. Mo�ete definisati neke od postavki upotrijebljevaju�i dugme udnu.';
$string['therewereerrors'] = 'Postoji gre�ka u Va�em podatku';
$string['upgradelogs'] = 'Zbog potpune fukcionalnosti, Va� stari pristup mora biti nadogra�en.  <a href=\"$a\">Vi�e informacija</a>\'';
$string['upgradelogsinfo'] = 'Nedavno su napravljene odre�ene promjene u pogledu �uvanja zapisa o posjetama. Da bi mogli vidjeti sve Va�e stare zapise na bazi aktivnosti, trebate ih a�urirati. Zavisno od sajta, takva akcija mo�e trajati dugo (i po nekoliko sati) i mo�e opteretiti bazu podataka na velikim sajtovima. Ako zapo�nete ovaj proces, onda ga trebate pustiti da se zavr�i tako �to �ete prozor pretra�iva�a ostaviti otvoren. Ne brinite - Va� sajt �e i dalje dobro raditi za korisnike u momentu dok se zapisi a�uriraju.  Da li �elite a�urirati zapise o posjetama? ';
$string['upgradesure'] = 'Va� Moodle fajl je promjenjen, i mo�ete automatski nadograditi Va� server sa ovom verzijom:
<p><b>$a</b></p>
<p>Jednom kada urdite ovo na mo�ete se vratiti nazad.</p> 
<p>Da li ste sigurni da �elite nadograditi ovaj server sa ovom verzijom?</p>';
$string['upgradinglogs'] = 'A�uriranje posjeta';

?>
