<?PHP // $Id: assignment.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // assignment.php - created with Moodle 1.4.3 + (2004083131)


$string['allowresubmit'] = 'Dozvoli ponovno podno�enje';
$string['assignmentdetails'] = 'Detalji zadatka';
$string['assignmentmail'] = '$a->teacher �e poslati neka ponovna uklju�enja na Va� odredjeni prijedlog za \'$a->assignment\' Pogledajte na:    $a->url

Mo�ete vidjeti dopunjavanje Va�eg odredjenog prijedloga:

$a->url';
$string['assignmentmailhtml'] = '$a->predava� je poslao povratne informacije na slanje Va�eg materijala \'<i>$a->assignment</i>\'<br /><br />Pogledajte na <a href=\"$a->url\">prilo�eni materijal</a>.';
$string['assignmentname'] = 'Naziv zadatka';
$string['assignmenttype'] = 'Vrsta zadatka';
$string['configmaxbytes'] = 'Podrazumijevana maksimalna veli�ina zadatka za sve zadatke na sajtu (vezano za ograni�enje kursa i ostala lokalna pode�avanja)';
$string['description'] = 'Opis';
$string['duedate'] = 'Datum dospje�a';
$string['duedateno'] = 'Datum nedospje�a';
$string['early'] = '$a raniji';
$string['existingfiledeleted'] = 'Postoje�i direktorijum je obrisan: $a';
$string['failedupdatefeedback'] = 'Neuspjelo a�uriranje povratne informacije o podnesenom materijalu za korisnika $a';
$string['feedback'] = 'Povratna sprega';
$string['feedbackupdated'] = 'Povratne informacije su poslane za $a korisnika';
$string['late'] = '$a kasnije';
$string['maximumgrade'] = 'Maksimalna ocjena';
$string['maximumsize'] = 'Maksimalna veli�ina';
$string['modulename'] = 'Zadatak';
$string['modulenameplural'] = 'Zadaci';
$string['newsubmissions'] = 'Zadaci su prilo�eni';
$string['notgradedyet'] = 'Nije ocjenjeno';
$string['notsubmittedyet'] = 'Nije prilo�eno';
$string['overwritewarning'] = 'Upozorenje: Ponovno dodavanje �e zamijeniti Va� trenutno prilo�eni materijal';
$string['saveallfeedback'] = 'Sa�uvaj sve moje odgovore';
$string['submissionfeedback'] = 'Povratna informacija o potvr�ivanju';
$string['submissions'] = 'Potvr�ivanja';
$string['submitassignment'] = 'Za slanje zadataka koristite ovu formu';
$string['submitted'] = 'Poslano';
$string['typeoffline'] = 'Aktivnost izvan mre�e (Offline)';
$string['typeuploadsingle'] = 'Dodajte datoteku';
$string['uploadbadname'] = 'Ova datoteka sadr�i nedozvoljene karaktere i ne mo�e biti dodana';
$string['uploadedfiles'] = 'Dodajte datoteke';
$string['uploaderror'] = 'Gre�ka! Datoteka nije sa�uvana na serveru';
$string['uploadfailnoupdate'] = 'Datoteka je ispravno dodana, ali njeno slanje nije a�urirano.';
$string['uploadfiletoobig'] = '�ao nam je, ali ova datoteka je prevelika (dozvoljena veli�ina datoteke je $a bytes)';
$string['uploadnofilefound'] = 'Datoteka nije prona�ena - da li ste sigurni da ste izvr�ili ispravan izbor datoteke za dodavanje?';
$string['uploadnotregistered'] = '\'$a\' je dodan ispravno, ali slanje nije registrovano!';
$string['uploadsuccess'] = 'Dodavanje \'$a\' je uspje�no obavljen';
$string['viewfeedback'] = 'Pregledajte ocjene zadataka i povratne informacije';
$string['viewsubmissions'] = 'Pregledajte $a prilo�ene zadatke';
$string['yoursubmission'] = 'Va�e slanje';

?>
