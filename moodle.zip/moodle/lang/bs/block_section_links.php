<?PHP // $Id: block_section_links.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // block_section_links.php - created with Moodle 1.4.3 + (2004083131)


$string['blockname'] = 'Sekcija linkova';
$string['jumptocurrenttopic'] = 'Pogledajte aktivnu temu';
$string['jumptocurrentweek'] = 'Pogledajte trenutnu sedmicu';
$string['topics'] = 'Teme';
$string['weeks'] = 'Sedmice';

?>
