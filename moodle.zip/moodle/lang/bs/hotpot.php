<?PHP // $Id: hotpot.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // hotpot.php - created with Moodle 1.4.3 + (2004083131)


$string['clearall'] = 'Po�istite sve';
$string['deleteall'] = 'Bri�ite sve';
$string['modulename'] = 'Kviz vru�eg krompira';
$string['modulenameplural'] = 'Kvizovi vru�eg krompira';
$string['really'] = 'Da li stvarno �elite obrisati sve rezultate sa ovog kviza?';
$string['strattemptlabel'] = 'Smjestiti: rezultat u kvizu, datum i vrijeme (dugotrajnost), [ka�njavanje]';

?>
