<?PHP // $Id: mediaplugin.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // mediaplugin.php - created with Moodle 1.4.3 + (2004083131)


$string['filtername'] = 'Multimedijalni dodatci';

?>
