<?PHP // $Id: error.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // error.php - created with Moodle 1.4.3 + (2004083131)


$string['confirmsesskeybad'] = 'Na�alost, ali va� radni klju� ne mo�e biti potvr�en za brigu van ove aktivnosti. Ova sigurnost predstavlja spre�avanje protiv neo�ekivanog ili zlonamjernog izvr�avanja na va�ne funkcije Va�eg imena. Molimo Vas da budete sigurni da stavarno �elite da izvr�ite ovu funkciju.';
$string['coursegroupunknown'] = 'Odgovaraju�i kurs za grupu $a nije zadat';
$string['erroronline'] = 'Gre�ka u liniji $a';
$string['fieldrequired'] = '$a je obavezno polje';
$string['filenotfound'] = '�ao mi je, zahtjevanu datoteku ne mogu prona�i';
$string['groupalready'] = 'Korisnik ve� pripada grupi $a';
$string['groupunknown'] = 'Grupa $a ne pripada datom kursu';
$string['invalidfieldname'] = '\"$a\" nije validno ime polja';
$string['missingfield'] = 'Nedostaje polje \"$a\"';
$string['modulerequirementsnotmet'] = 'Modul \"$a->modulename\" ($a->moduleversion) nije instalisan. Preporu�ujemo noviju verziju Moodle-a (trenutno koristite $a->currentmoodle, preporu�ujemo vam $a->requiremoodle).';
$string['notavailable'] = 'Trenutno nije na raspolaganju';
$string['restricteduser'] = '�ao nam je, ali va� teku�i nalog \"$a\" je ograni�en i ne mo�ete uraditi ovu akciju.';
$string['sessionipnomatch'] = 'Na�alost, ali Va� IP broj izgleda da je imao promjena kada ste se prvi put upiasali. Ova sigurnost predstavlja spre�avanje krakera da ukradu Va� indentitet dok se upisuje na ovaj sajt. Normalni korisnici ne bi trebalo da vide ovu poruku - molimo Vas da tra�ite pomo� od administratora sajta.';
$string['unknowncourse'] = 'Nepoznato ime kursa \"$a\"';
$string['usernotaddederror'] = 'Korisnik \"$a\" nije dodat - nepoznata gre�ka';
$string['usernotaddedregistered'] = 'Korisnik \"$a\" nije dodat - ve� je registrovan';
$string['usernotavailable'] = 'Dedalji o ovome korisniku nisu Vam dostupni';

?>
