<?PHP // $Id: enrol_internal.php,v 1.1.2.3 2006/02/06 09:59:29 moodler Exp $ 
      // enrol_internal.php - created with Moodle 1.4.3 + (2004083131)


$string['description'] = 'Ovo je podrazumijevana vrijednost upisa. Postoje dva  glavna na�ina da se student mo�e upisati na poseban kurs.
<ul>
<li>Nastavnici i administrator mogu upisati studenta ru�no koriste�i link na Kurs Administrator meniju unutar kursa.</li>
<li>Kurs mora imati definisanu lozinku, poznatu kao \"upisni klju�\". Svakom ko zna ovaj klju� dostupno je da doda sebe na kurs.</li>
</ul>';
$string['enrolname'] = 'Bitan spisak';

?>
