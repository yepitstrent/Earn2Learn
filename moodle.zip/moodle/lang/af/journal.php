<?PHP // $Id: journal.php,v 1.3.2.3 2006/02/06 09:59:25 moodler Exp $ 
      // journal.php - created with Moodle 1.5 UNSTABLE DEVELOPMENT (2005010100)


$string['alwaysopen'] = 'Altyd oop';
$string['blankentry'] = 'Oop inskrywing';
$string['daysavailable'] = 'Dae beskikbaar';
$string['editingended'] = 'Redigerings periode het geeindig';
$string['editingends'] = 'Redigerings periode eindig';
$string['entries'] = 'Inskrywings';
$string['feedbackupdated'] = 'Terugvoer opgedateer vir $a inskrywings';
$string['journalmail'] = '$a->teacher het terugvoer gepos op jou joernaal inskrywing van \'$a->journal\'

Dit is aangeheg aan jou joernaal inskrywing: $a->url';
$string['journalmailhtml'] = '$a->teacher het terugvoer gepos op jou joernaal inskrywing van 
\'<i>$a->journal</i>\'<br /><br />
Dit is aangeheg aan jou <a href=\"$a->url\">joernaal inskrywing</a>.';
$string['journalname'] = 'Joernaal naam';
$string['journalquestion'] = 'Joernaal vraag';
$string['journalrating1'] = 'Nie tevrede nie';
$string['journalrating2'] = 'Bevredigend';
$string['journalrating3'] = 'Uitstaande';
$string['modulename'] = 'Joernaal';
$string['modulenameplural'] = 'Joernale';
$string['newjournalentries'] = 'Nuwe joernaal inskrywings';
$string['noentry'] = 'Geen toegang';
$string['noratinggiven'] = 'Geen evaluasie';
$string['notopenuntil'] = 'Die joernaal sal eers geopen word op ';
$string['notstarted'] = 'Jy het nog nie die joernaal begin nie';
$string['overallrating'] = 'Algehele evaluasie';
$string['rate'] = 'Evalueer';
$string['saveallfeedback'] = 'Stoor al my terugvoer';
$string['startoredit'] = 'Begin of redigeer my joernaal inskrywing';
$string['viewallentries'] = 'Sien $a joernaal inskrywings';

?>
