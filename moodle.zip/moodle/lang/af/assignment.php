<?PHP // $Id: assignment.php,v 1.3.2.3 2006/02/06 09:59:25 moodler Exp $ 
      // assignment.php - created with Moodle 1.5 UNSTABLE DEVELOPMENT (2005010100)


$string['allowresubmit'] = 'Laat her-inlewering toe';
$string['assignmentdetails'] = 'Opdrag beskrywing';
$string['assignmentmail'] = '$a->teacher het kommentaar gelewer op jou opdrag van \'$a->assignment\'

Kommentaar is aangeheg by jou opdrag:

    $a->url';
$string['assignmentmailhtml'] = '$a->teacher het kommentaar gelewer op jou opdrag van 
\'<i>$a->assignment</i>\'<br /><br />
Dit is aangeheg by jou <a href=\"$a->url\"> opdrag</a>.';
$string['assignmentname'] = 'Opdrag naam';
$string['assignmenttype'] = 'Opdrag tipe';
$string['description'] = 'Beskrywing';
$string['duedate'] = 'Inhandings datum';
$string['early'] = '$a vroeg';
$string['failedupdatefeedback'] = 'Opdrag terugvoer van gebruiker $a nie gestoor nie';
$string['feedback'] = 'Terugvoer';
$string['feedbackupdated'] = 'Terug voer gepos vir $a persone';
$string['late'] = '$a laat';
$string['maximumgrade'] = 'Maksimum punt';
$string['maximumsize'] = 'Maksimum groote';
$string['modulename'] = 'Opdrag';
$string['modulenameplural'] = 'Opdragte';
$string['newsubmissions'] = 'Opdragte in gelewer';
$string['notgradedyet'] = 'Nog nie gemerk nie';
$string['notsubmittedyet'] = 'Nog nie in gehandig';
$string['overwritewarning'] = 'Waarskuwing: her-inlewering sal jou huidige opdrag VERVANG';
$string['saveallfeedback'] = 'Stoor my terugvoer';
$string['submissionfeedback'] = 'Opdrag terugvoer';
$string['submissions'] = 'Ingestuurde opdragte';
$string['submitassignment'] = 'Handig jou opdrag in met di� vorm';
$string['submitted'] = 'Ontvang';
$string['typeoffline'] = 'Ongekoppelde aktiwiteite';
$string['typeuploadsingle'] = 'Laai \'n l�er op';
$string['uploadbadname'] = 'L�er naam bevat vreemde karakters en kon nie gestoor word nie';
$string['uploadedfiles'] = 'Gestoorde l�ers';
$string['uploaderror'] = '\'n Fout het ontstaan toe jou l�er op die bediener gestoor is';
$string['uploadfailnoupdate'] = 'L�er is opgelaai MAAR kon nie gestoor word nie!';
$string['uploadfiletoobig'] = 'Jammer, die l�er is te groot(die limiet is $a bytes)';
$string['uploadnofilefound'] = 'Geen l�er gevind - maak seker dat \'n l�er geselekteer is';
$string['uploadnotregistered'] = '\'$a\' is opgelaai, MAAR is nie geregistreer nie!';
$string['uploadsuccess'] = '\'$a\' suksesvol ontvang';
$string['viewfeedback'] = 'Kyk na punte en terugvoer';
$string['viewsubmissions'] = 'Kyk na  $a ingehandigde opdragte';
$string['yoursubmission'] = 'Jou ingestuurde opdrag';

?>
