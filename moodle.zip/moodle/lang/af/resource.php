<?PHP // $Id: resource.php,v 1.3.2.3 2006/02/06 09:59:26 moodler Exp $ 
      // resource.php - created with Moodle 1.5 UNSTABLE DEVELOPMENT (2005010100)


$string['addresource'] = 'Voeg hulpbron by';
$string['configframesize'] = 'Wanneer \'n webblad of \'n l�er vertoon word in \'n raam, is die waarde die grootte (in pixels) van die boonste raam (wat die navigasie bevat).';
$string['editingaresource'] = 'Redigeer hulpbron';
$string['example'] = 'Voorbeeld';
$string['exampleurl'] = 'http://www.example.com/somedirectory/somefile.html';
$string['filename'] = 'L�ernaam';
$string['fulltext'] = 'Vol teks';
$string['htmlfragment'] = 'HTML fragment';
$string['modulename'] = 'Hulpbron';
$string['modulenameplural'] = 'Hulpbronne';
$string['neverseen'] = 'Nooit gesien';
$string['newdirectories'] = 'Vertoon l�ergids skakels';
$string['newfullscreen'] = 'Vul die hele skerm';
$string['newheight'] = 'Verstek venster hoogte (in pixels)';
$string['newlocation'] = 'Vertoon die lokasie balk';
$string['newmenubar'] = 'Vertoon die kieslys balk';
$string['newresizable'] = 'Vertoon die venster om van grootte te verander';
$string['newscrollbars'] = 'Laat die venster toe om te rol';
$string['newstatus'] = 'Vertoon status balk';
$string['newtoolbar'] = 'Vertoon gereedskap balk';
$string['newwidth'] = 'Vertek venster wydte (in pixels)';
$string['newwindow'] = 'Nuwe venster';
$string['newwindowopen'] = 'Vertoon die hulpbron in \'n nuwe venster';
$string['note'] = 'Nota';
$string['notefile'] = 'Om meer l�ers by die kursus te sit (sodat hulle in die lys verskyn) gebruik die 
<a href=\"$a\">L�er Bestuurder</a>.';
$string['notypechosen'] = 'Jy moet \'n tipe kies. Gebruik jou \'Back\' knoppie op terug te gaan en weer te probeer';
$string['resourcetype'] = 'Tipe hulpbron';
$string['resourcetype1'] = 'Verwysing';
$string['resourcetype2'] = 'Web Blad';
$string['resourcetype3'] = 'Op gelaaide l�er';
$string['resourcetype4'] = 'Gewone teks';
$string['resourcetype5'] = 'Web skakel';
$string['resourcetype6'] = 'HTML teks';
$string['resourcetype7'] = 'Program';
$string['resourcetype8'] = 'Wiki teks';

?>
