<?PHP // $Id: choice.php,v 1.3.2.3 2006/02/06 09:59:25 moodler Exp $ 
      // choice.php - created with Moodle 1.5 UNSTABLE DEVELOPMENT (2005010100)


$string['answered'] = 'Beantwoord';
$string['choice'] = 'Keuse $a';
$string['choicename'] = 'Keuse naam';
$string['choicetext'] = 'Keuse teks';
$string['modulename'] = 'Keuse Vraag';
$string['modulenameplural'] = 'Keuse Vrae';
$string['notanswered'] = 'Nog nie beantwoord';
$string['publish'] = 'Publiseer resultate';
$string['publishanonymous'] = 'Publiseer anonieme resultate, moenie studente name wys nie';
$string['publishnames'] = 'Publiseer resultate, wys name en hul keuses';
$string['publishnot'] = 'Moenie resultate aan studente publiseer nie';
$string['responses'] = 'Terugvoer';
$string['responsesto'] = 'Terugvoer aan $a';
$string['savemychoice'] = 'Stoor my keuse';
$string['viewallresponses'] = 'Kyk na terugvoer ($a)';

?>
