<?PHP // $Id: chat.php,v 1.2.2.3 2006/02/06 09:59:25 moodler Exp $ 
      // chat.php - created with Moodle 1.5 UNSTABLE DEVELOPMENT (2005010100)


$string['beep'] = 'roep';
$string['chatintro'] = 'Inleiding teks';
$string['chatname'] = 'Naam van die gesels kamer';
$string['chatreport'] = 'Gesels sessie';
$string['chattime'] = 'Volgende gesels sessie';
$string['configoldping'] = 'Hoe lank na ons die laaste keer van \'n gebruiker gehoor het moet ons aanvaar dat die gebruiker weg is?';
$string['configrefreshroom'] = 'Hoe gereeld moet die gesels kamer herlaai word? (in sekondes).  \'n Lae stelling sal die gesels kamer vinniger laat lyk, maar dit sit \'n ho�r lading op die webbediener as baie mense gesels';
$string['configrefreshuserlist'] = 'Hoe gereeld moet die lys van gebruikers herlaai word? (in sekondes)';
$string['currentchats'] = 'Aktiewe gesels sessies';
$string['currentusers'] = 'Huidige gebruikers';
$string['donotusechattime'] = 'Moenie gesels tye publiseer nie';
$string['enterchat'] = 'Klik hier om die gesels kamer in te gaan';
$string['errornousers'] = 'Geen gebruikers gevind!';
$string['helpchatting'] = 'Hulp met gesels';
$string['idle'] = 'Stil';
$string['messagebeepseveryone'] = '$a roep almal!';
$string['messagebeepsyou'] = '$a het jou geroep!';
$string['messageenter'] = '$a het nou net die gesels kamer in gekom';
$string['messageexit'] = '$a het die gesels kamer verlaat';
$string['messages'] = 'Boodskappe';
$string['modulename'] = 'Gesels';
$string['modulenameplural'] = 'Gesels';
$string['neverdeletemessages'] = 'Moet nooit boodskappe uitwis nie';
$string['nextsession'] = 'Volgende geskeduleerde sessie';
$string['nomessages'] = 'Geen boodskappe';
$string['repeatdaily'] = 'Selfde tyd elke dag';
$string['repeatnone'] = 'Geen herhalings - publiseer slegs die geskeduleerde tyd';
$string['repeattimes'] = 'Herhaal sessies';
$string['repeatweekly'] = 'Selfde tyd elke week';
$string['savemessages'] = 'Stoor sessies wat verby is';
$string['seesession'] = 'Kyk na die sessie';
$string['sessions'] = 'Gesels sessies';
$string['strftimemessage'] = '%%H:%%M';
$string['studentseereports'] = 'Almal kan na sessies kyk wat verby is';
$string['viewreport'] = 'Kyk na sessies wat verby is';

?>
