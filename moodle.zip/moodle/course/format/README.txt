Course formats
--------------

To add a new course format, just duplicate one of the 
existing folders in here with a new name (eg coollayout).
Then edit lang/en/moodle and add a new string like:

$string['formatcoollayout'] = 'Cool Layout';

