<?PHP // $Id: version.php,v 1.1.2.5 2005/12/02 14:12:26 ethem Exp $

$module->version  = 2005071602;
$module->requires = 2004081800;

?>
