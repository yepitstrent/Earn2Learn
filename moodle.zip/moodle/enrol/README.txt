ENROLMENT MODULES
-----------------

(Yes, that's the correct English spelling  ;-) )

enrol.class.php contains the base class and explains 
all the possible functions that an enrolment module 
can have.

Each plugin is in a subfolder here and extends the
base class as necessary.


Martin Dougiamas and Shane Elliott, Moodle.com

