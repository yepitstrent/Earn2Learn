<?php
require_once("$CFG->dirroot/enrol/enrol.class.php");

class enrolment_plugin extends enrolment_base {
    /// nothing to do - it's already perfect!
}

?>
