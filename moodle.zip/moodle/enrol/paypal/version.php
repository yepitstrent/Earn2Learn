<?PHP // $Id: version.php,v 1.1 2004/08/19 09:36:20 moodler Exp $

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of this enrolment module
///  This fragment is called by admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$module->version  = 2004081800;   // This module's version

$module->requires = 2004081800;   // Requires this Moodle version

?>
