<?PHP  //$Id: version.php,v 1.10.2.1 2005/09/02 04:58:57 mjollnir_ Exp $
// This file defines the current version of the
// blocks code that is being used.  This can be
// compared against the values stored in the
// database (blocks_version) to determine whether upgrades should
// be performed (see db/backup_*.php)

$blocks_version = 2005022401;   // The current version is a date (YYYYMMDDXX)
