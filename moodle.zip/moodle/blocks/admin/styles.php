.block_adminblock .content {
    text-align: center;
    padding: 10px;
}
