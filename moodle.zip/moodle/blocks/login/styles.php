.block_login .logintable {
  text-align:center;
}

.block_login .loginform {
  display:inline;
}
