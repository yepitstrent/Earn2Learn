.block_course_summary .content {
    padding:10px;
}
