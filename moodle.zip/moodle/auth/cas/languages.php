<?PHP
// version $Id: languages.php,v 1.2 2005/03/13 10:11:13 phoenixfr Exp $
// List of CAS langages.
// You can add langages in /CAS/langage.
// Please send them to http://esup-phpcas.sourceforge.net
$CASLANGUAGES = array (
"greek" => "Modern Greek",
"english" => "English",
"french" => "French");
?>