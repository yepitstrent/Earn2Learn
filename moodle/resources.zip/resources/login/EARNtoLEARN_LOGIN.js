// Created by iWeb 3.0.4 local-build-20150311

setTransparentGifURL('Media/transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({stroke_0:new IWEmptyStroke()});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('EARNtoLEARN_LOGIN_files/EARNtoLEARN_LOGINMoz.css')
fixAllIEPNGs('Media/transparent.gif');applyEffects()}
